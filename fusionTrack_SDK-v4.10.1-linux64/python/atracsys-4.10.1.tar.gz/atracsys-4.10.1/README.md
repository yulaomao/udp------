# Atracsys fusionTrack and spryTrack Wrapper Package

This package allows you to interact with Atracsys fusionTrack and spryTrack systems.

## Installation

In order to install this package, you will need:
- Cmake 3.10 at least.
- Visual Studio 2015 or greater on Windows (since the sources need c++11 full support).
- gcc 5 on Linux (not tested on more recent releases of gcc).
- git available on the command line (on Windows, please use git for Windows).
- Atracsys SDK corresponding to the version of the python package.

During the installation, the wrapper will get compiled against the fusionTrack SDK, the spryTrack SDK
or both depending on the packages installed on your system.

On Linux, the installation checks for the environment variables `ATRACSYS_FTK_HOME` and `ATRACSYS_STK_HOME`
to find out what SDK is installed (and where they are installed). Please make these variables point to 
the installation folder of your SDK(s).

## Usage

The python API exported by this packages tries to be as closed as possible from the Atracsys `C++` API.
A complete example is given in the doc/python folder of your SDK(s) installation.

## Help

The full documentation is in the doc/python folder of your SDK(s) installation.