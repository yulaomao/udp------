import os

if os.name == 'nt':
    import winreg
    import ctypes
    from ctypes import wintypes
    from contextlib import contextmanager

    # This case with the env variable set is mostly used when
    # use interally at Atracsys. In that case this points to the directory
    # where the built binaries are put
    ftk_home_path = os.environ.get('ATRACSYS_FTK_HOME')
    if ftk_home_path is None:
        registry_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Atracsys\fusionTrack" , 0,
                                      winreg.KEY_READ)
        sdk_path, regtype = winreg.QueryValueEx(registry_key, "Root")
        sdk_path=os.path.join(sdk_path,'bin')
    else:
        sdk_path=ftk_home_path

    print("Using SDK installed in {0}".format(sdk_path))
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel32.SetDllDirectoryW(sdk_path)

from _atracsys_ftk import *
