#include <EventData.hpp>

#include <tuple>

namespace atracsys
{
    class WrappedEvtActiveMarkersMaskV1Data : public EvtActiveMarkersMaskV1Data
    {
    public:
        WrappedEvtActiveMarkersMaskV1Data() = default;

        WrappedEvtActiveMarkersMaskV1Data( const WrappedEvtActiveMarkersMaskV1Data& other ) = default;
        WrappedEvtActiveMarkersMaskV1Data( WrappedEvtActiveMarkersMaskV1Data&& other ) = default;

        virtual ~WrappedEvtActiveMarkersMaskV1Data() = default;

        WrappedEvtActiveMarkersMaskV1Data& operator=( const WrappedEvtActiveMarkersMaskV1Data& other ) =
          default;
        WrappedEvtActiveMarkersMaskV1Data& operator=( WrappedEvtActiveMarkersMaskV1Data&& other ) = default;

        std::tuple< bool, bool > isMarkerPaired( const uint32_t idx ) const;
    };

    class WrappedEvtActiveMarkersMaskV2Data : public EvtActiveMarkersMaskV2Data
    {
    public:
        WrappedEvtActiveMarkersMaskV2Data() = default;

        WrappedEvtActiveMarkersMaskV2Data( const WrappedEvtActiveMarkersMaskV2Data& other ) = default;
        WrappedEvtActiveMarkersMaskV2Data( WrappedEvtActiveMarkersMaskV2Data&& other ) = default;

        virtual ~WrappedEvtActiveMarkersMaskV2Data() = default;

        WrappedEvtActiveMarkersMaskV2Data& operator=( const WrappedEvtActiveMarkersMaskV2Data& other ) =
          default;
        WrappedEvtActiveMarkersMaskV2Data& operator=( WrappedEvtActiveMarkersMaskV2Data&& other ) = default;

        std::tuple< bool, bool > isMarkerPaired( const uint32_t idx ) const;

        std::tuple< bool, bool > isMarkerInError( const uint32_t idx ) const;
    };
}  // namespace atracsys
