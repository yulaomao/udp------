#pragma once

#include <AdditionalDataStructures.hpp>

#include <tuple>

class WrappedEioTaggingV1 : public atracsys::EvtEioTaggingV1Data
{
public:
    explicit WrappedEioTaggingV1( const atracsys::EvtEioTaggingV1Data& other );

    WrappedEioTaggingV1() = default;

    WrappedEioTaggingV1( const WrappedEioTaggingV1& other ) = default;

    WrappedEioTaggingV1( WrappedEioTaggingV1&& other ) = default;

    ~WrappedEioTaggingV1() = default;

    WrappedEioTaggingV1& operator=( const WrappedEioTaggingV1& other ) = default;
    WrappedEioTaggingV1& operator=( WrappedEioTaggingV1&& other ) = default;

    bool operator==( const WrappedEioTaggingV1& other ) const;

    std::tuple< bool, uint32_t > tagId( const size_t portNumber ) const;

    std::tuple< bool, EvtEioTaggingV1Data::TaggingMode > tagMode( const size_t portNumber ) const;

    std::tuple< bool, uint64_t > timestamp( const size_t portNumber ) const;
};
