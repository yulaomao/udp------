#include "WrappedActiveMarkersMask.hpp"

using namespace std;

namespace atracsys
{
    tuple< bool, bool > WrappedEvtActiveMarkersMaskV1Data::isMarkerPaired( const uint32_t idx ) const
    {
        bool isPaired{ false };
        bool status{ EvtActiveMarkersMaskV1Data::isMarkerPaired( idx, isPaired ) };

        return make_tuple( status, isPaired );
    }

    tuple< bool, bool > WrappedEvtActiveMarkersMaskV2Data::isMarkerPaired( const uint32_t idx ) const
    {
        bool isPaired{ false };
        bool status{ EvtActiveMarkersMaskV2Data::isMarkerPaired( idx, isPaired ) };

        return make_tuple( status, isPaired );
    }

    tuple< bool, bool > WrappedEvtActiveMarkersMaskV2Data::isMarkerInError( const uint32_t idx ) const
    {
        bool isInError{ false };
        bool status{ EvtActiveMarkersMaskV2Data::isMarkerInError( idx, isInError ) };

        return make_tuple( status, isInError );
    }
}  // namespace atracsys
