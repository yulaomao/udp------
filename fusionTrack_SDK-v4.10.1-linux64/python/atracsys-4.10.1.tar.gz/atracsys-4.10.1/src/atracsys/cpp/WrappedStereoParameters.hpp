#pragma once

#include "WrappedCameraParameters.hpp"

#include <ftkInterface.h>

#include <array>

class WrappedStereoParameters : public ftkStereoParameters
{
public:
    WrappedStereoParameters() = default;
    WrappedStereoParameters( const ftkStereoParameters& params );
    ~WrappedStereoParameters() = default;

    const WrappedCameraParameters& leftCamera() const;
    const WrappedCameraParameters& rightCamera() const;

    const std::array< float, 3u >& translation() const;
    const std::array< float, 3u >& rotation() const;

protected:
    WrappedCameraParameters _LeftCamera{};
    WrappedCameraParameters _RightCamera{};
    std::array< float, 3u > _Translation{};
    std::array< float, 3u > _Rotation{};
};
