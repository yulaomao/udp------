#include "WrappedCameraParameters.hpp"

#include <algorithm>

using namespace std;

WrappedCameraParameters::WrappedCameraParameters( const ftkCameraParameters& params )
    : ftkCameraParameters( params )
{
    copy( begin( params.FocalLength ), end( params.FocalLength ), _FocalLength.begin() );
    copy( begin( params.OpticalCentre ), end( params.OpticalCentre ), _OpticalCentre.begin() );
    copy( begin( params.Distorsions ), end( params.Distorsions ), _Distorsions.begin() );
}

const array< float, 2u > WrappedCameraParameters::focalLength() const
{
    return _FocalLength;
}

const array< float, 2u > WrappedCameraParameters::opticalCentre() const
{
    return _OpticalCentre;
}

const array< float, 5u > WrappedCameraParameters::distorsions() const
{
    return _Distorsions;
}
