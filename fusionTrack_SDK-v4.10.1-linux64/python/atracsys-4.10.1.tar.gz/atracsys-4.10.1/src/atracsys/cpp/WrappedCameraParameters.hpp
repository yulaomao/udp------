#pragma once

#include <ftkInterface.h>

#include <array>

class WrappedCameraParameters : public ftkCameraParameters
{
public:
    WrappedCameraParameters() = default;
    WrappedCameraParameters( const ftkCameraParameters& params );
    ~WrappedCameraParameters() = default;

    const std::array< float, 2u > focalLength() const;
    const std::array< float, 2u > opticalCentre() const;
    const std::array< float, 5u > distorsions() const;

protected:
    std::array< float, 2u > _FocalLength{};
    std::array< float, 2u > _OpticalCentre{};
    std::array< float, 5u > _Distorsions{};
};
