#include "WrappedEioTaggingV1Data.hpp"

using namespace atracsys;
using namespace std;

WrappedEioTaggingV1::WrappedEioTaggingV1( const EvtEioTaggingV1Data& other )
    : EvtEioTaggingV1Data( other )
{
}

bool WrappedEioTaggingV1::operator==( const WrappedEioTaggingV1& other ) const
{
    return TaggingInfo[ 0u ].EioTagMode == other.TaggingInfo[ 0u ].EioTagMode &&
           TaggingInfo[ 1u ].EioTagMode == other.TaggingInfo[ 1u ].EioTagMode &&
           TaggingInfo[ 0u ].EioTagId == other.TaggingInfo[ 0u ].EioTagId &&
           TaggingInfo[ 1u ].EioTagId == other.TaggingInfo[ 1u ].EioTagId &&
           TaggingInfo[ 0u ].EioTagTimestamp == other.TaggingInfo[ 0u ].EioTagTimestamp &&
           TaggingInfo[ 1u ].EioTagTimestamp == other.TaggingInfo[ 1u ].EioTagTimestamp;
}

tuple< bool, uint32_t > WrappedEioTaggingV1::tagId( const size_t portNumber ) const
{
    uint32_t tmp{ 0u };
    bool retVal( EvtEioTaggingV1Data::tagId( portNumber, tmp ) );
    return make_tuple( retVal, tmp );
}

tuple< bool, EvtEioTaggingV1Data::TaggingMode > WrappedEioTaggingV1::tagMode( const size_t portNumber ) const
{
    EvtEioTaggingV1Data::TaggingMode tmp{ EvtEioTaggingV1Data::TaggingMode::Disabled };
    bool retVal( EvtEioTaggingV1Data::tagMode( portNumber, tmp ) );
    return make_tuple( retVal, tmp );
}

tuple< bool, uint64_t > WrappedEioTaggingV1::timestamp( const size_t portNumber ) const
{
    uint64_t tmp{ 0u };
    bool retVal( EvtEioTaggingV1Data::timestamp( portNumber, tmp ) );
    return make_tuple( retVal, tmp );
}
