#include "WrappedStereoParameters.hpp"

#include <algorithm>

using namespace std;

WrappedStereoParameters::WrappedStereoParameters( const ftkStereoParameters& params )
    : ftkStereoParameters( params )
    , _LeftCamera( params.LeftCamera )
    , _RightCamera( params.RightCamera )
{
    copy( begin( params.Translation ), end( params.Translation ), _Translation.begin() );
    copy( begin( params.Rotation ), end( params.Rotation ), _Rotation.begin() );
}

const WrappedCameraParameters& WrappedStereoParameters::leftCamera() const
{
    return _LeftCamera;
}

const WrappedCameraParameters& WrappedStereoParameters::rightCamera() const
{
    return _RightCamera;
}

const array< float, 3u >& WrappedStereoParameters::translation() const
{
    return _Translation;
}

const array< float, 3u >& WrappedStereoParameters::rotation() const
{
    return _Rotation;
}
